//  (c) Copyright 2013 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------
// Smoke test program for bit accurate C model

#include <iostream>
#include <vector>
#include <complex>
#include <cstdlib>

#define _USE_MATH_DEFINES

#include <math.h>
#include <fstream> // for debug only

#include "cmpy_v6_0_bitacc_cmodel.h"
#include "gmp.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

using namespace std;

// Debug functions
#define DEBUG 1

static void msg_print(void* dummy, int error, const char* msg)
{
  std::cout << msg << std::endl;
}
// End of debug functions

//Utility functions
void print_mpz_complex(const xip_mpz_complex p) {
  printf(" real = ");
  mpz_out_str(0,10,p.re);
  printf(" imaginary = ");
  mpz_out_str(0,10,p.im);
  printf("\n");
}


#define DATA_SIZE 10

int main()
{
  size_t ii; //loop variable for data samples
  xip_uint roundbit;
  xip_complex value;

  cout << "C model version = " << xip_cmpy_v6_0_get_version() << endl;

  // Create a configuration structure
  xip_cmpy_v6_0_config config, config_ret;
  xip_status status = xip_cmpy_v6_0_default_config(&config);

  if (status != XIP_STATUS_OK) {
    cerr << "ERROR: Could not get C model default configuration" << endl;
    return XIP_STATUS_ERROR;
  }

  //Firstly, create and exercise a simple configuration.
  config.APortWidth  = 16;
  config.BPortWidth  = 16;
  config.OutputWidth = 33;
  config.RoundMode   = XIP_CMPY_V6_0_TRUNCATE; //Note that the check later in this file assumes full width

  // Create model object
  xip_cmpy_v6_0* cmpy_std;
  cmpy_std = xip_cmpy_v6_0_create(&config, &msg_print, 0);

  if (status != XIP_STATUS_OK) {
    cerr << "ERROR: Could not create C model state object" << endl;
    return XIP_STATUS_ERROR;
  }

  // Can we read back the updated configuration correctly?
  if (xip_cmpy_v6_0_get_config(cmpy_std, &config_ret) != XIP_STATUS_OK) {
    cerr << "ERROR: Could not retrieve C model configuration" << endl;
  }

  int number_of_samples = DATA_SIZE;
  // Declare any arrays in the request structure and write pointers to them into the request structure

  // Create request and response structures
  // Create input data packet for operand A
  xip_array_complex* reqa = xip_array_complex_create();
  xip_array_complex_reserve_dim(reqa,1); //dimensions are (Number of samples)
  reqa->dim_size = 1;
  reqa->dim[0] = number_of_samples;
  reqa->data_size = reqa->dim[0];
  if (xip_array_complex_reserve_data(reqa,reqa->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for request as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for input data packet!" << endl;
    exit(2);
  }

  // Create input data packet for operand B
  xip_array_complex* reqb = xip_array_complex_create();
  xip_array_complex_reserve_dim(reqb,1); //dimensions are (Number of samples)
  reqb->dim_size = 1;
  reqb->dim[0] = number_of_samples;
  reqb->data_size = reqb->dim[0];
  if (xip_array_complex_reserve_data(reqb,reqb->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for request as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for input data packet!" << endl;
    exit(2);
  }

  // Create input data packet for ctrl input (Round bit)
  xip_array_uint* reqctrl = xip_array_uint_create();
  xip_array_uint_reserve_dim(reqctrl,1); //dimensions are (Number of samples)
  reqctrl->dim_size = 1;
  reqctrl->dim[0] = number_of_samples;
  reqctrl->data_size = reqctrl->dim[0];
  if (xip_array_uint_reserve_data(reqctrl,reqctrl->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for request as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for input data packet!" << endl;
    exit(2);
  }

  //create input data
  xip_complex a,b;
  for (ii = 0; ii < DATA_SIZE; ii++)
  {
    roundbit = ii % 2;
    a.re = (xip_real)ii;
    a.im = (xip_real)ii;
    b.re = (xip_real)(16-ii);
    b.im = (xip_real)ii;
    if (xip_cmpy_v6_0_xip_array_complex_set_data(reqa, a, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_complex_set_data" << endl;
    if (xip_cmpy_v6_0_xip_array_complex_set_data(reqb, b, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_complex_set_data" << endl;
    if (xip_cmpy_v6_0_xip_array_uint_set_data(reqctrl, roundbit, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_uint_set_data" << endl;
    cout << "Sample " << ii << " a = " << a.re << " + j" << a.im << endl;
    cout << "Sample " << ii << " b = " << b.re << " + j" << b.im << endl;

#if(DEBUG)
    //Check that data values can be read back from the input data structures
    if (xip_cmpy_v6_0_xip_array_complex_get_data(reqb, &value, ii) != XIP_STATUS_OK)
      cerr << "Error in xip_array_complex_get_data" << endl;
    cout << "input array b sample " << ii << ", real = " << value.re << " imag = " << value.im << endl;
#endif
  }

  // Request memory for output data
  xip_array_complex* response = xip_array_complex_create();
  xip_array_complex_reserve_dim(response,1); //dimensions are (Number of samples)
  response->dim_size = 1;
  response->dim[0] = number_of_samples;
  response->data_size = response->dim[0];
  if (xip_array_complex_reserve_data(response,response->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for response as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for output data packet!" << endl;
    exit(3);
  }

  // Run the model
  cout << "Running the C model..." << endl;

  if (xip_cmpy_v6_0_data_do(cmpy_std, reqa, reqb, reqctrl, response) != XIP_STATUS_OK) {
    cerr << "ERROR: C model did not complete successfully" << endl;
    xip_array_complex_destroy(reqa);
    xip_array_complex_destroy(reqb);
    xip_array_uint_destroy(reqctrl);
    xip_array_complex_destroy(response);
    xip_cmpy_v6_0_destroy(cmpy_std);
    return XIP_STATUS_ERROR;
  } else {
    cout << "C model completed successfully" << endl;
  }

#if(DEBUG)
  // When enabled, this will print the result data to stdout
  for(int sample = 0; sample < number_of_samples; sample++) {
    xip_cmpy_v6_0_xip_array_complex_get_data(response, &value, sample);
    cout << "Sample " << sample << ":  out real = " << value.re << " imag = " << value.im << endl;
  }
#endif

  // Check response is correct
  for (ii = 0; ii < DATA_SIZE; ii++)
  {
    //This example has natural width, so simple calculation
    xip_complex expected, got, x, y;
    xip_cmpy_v6_0_xip_array_complex_get_data(reqa, &x, ii);
    xip_cmpy_v6_0_xip_array_complex_get_data(reqb, &y, ii);
    xip_cmpy_v6_0_xip_array_complex_get_data(response, &got, ii);

    //Note that the following equations assume that the output width is the full
    //width of the calculation, i.e. neither truncation nor rounding occurs
    expected.re = x.re*y.re - x.im*y.im;
    expected.im = x.re*y.im + x.im*y.re;
    if (expected.re != got.re || expected.im != got.im) {
      cerr << "ERROR: C model data output is incorrect for sample" << ii << "Expected real = " << expected.re << " imag = " << expected.im << " Got real = " << got.re << " imag = " << got.im << endl;

      xip_array_complex_destroy(reqa);
      xip_array_complex_destroy(reqb);
      xip_array_uint_destroy(reqctrl);
      xip_array_complex_destroy(response);
      xip_cmpy_v6_0_destroy(cmpy_std);
      return XIP_STATUS_ERROR;
    } else {
      cout << "Sample " << ii << " was as expected" << endl;
    }
  }
  cout << "C model data output is correct" << endl;

  // Clean up
  xip_array_complex_destroy(reqa);
  xip_array_complex_destroy(reqb);
  xip_array_uint_destroy(reqctrl);
  xip_array_complex_destroy(response);
  cout << "C model input and output data freed" << endl;

  xip_cmpy_v6_0_destroy(cmpy_std);
  cout << "C model destroyed" << endl;

  //End of test of simple configuration

  ////////////////////////////////////////
  //Now do the same using mpz_complex data
  ////////////////////////////////////////

  // Create a configuration structure
  xip_cmpy_v6_0_config config_mpz, config_mpz_ret;
  status = xip_cmpy_v6_0_default_config(&config_mpz);

  if (status != XIP_STATUS_OK) {
    cerr << "ERROR: Could not get C model default configuration" << endl;
    return XIP_STATUS_ERROR;
  }

  //This second example configures and executes a larger model and demonstrates rounding
  config_mpz.APortWidth  = 32;
  config_mpz.BPortWidth  = 32;
  config_mpz.OutputWidth = 60;
  config_mpz.RoundMode   = XIP_CMPY_V6_0_ROUND;

  xip_uint NaturalWidth = config_mpz.APortWidth + config_mpz.BPortWidth +1;

  // Create model object
  xip_cmpy_v6_0* cmpy_mpz;
  cmpy_mpz = xip_cmpy_v6_0_create(&config_mpz, &msg_print, 0);

  if (status != XIP_STATUS_OK) {
    cerr << "ERROR: Could not create C model state object" << endl;
    return XIP_STATUS_ERROR;
  }

  // Can we read back the updated configuration correctly?
  if (xip_cmpy_v6_0_get_config(cmpy_mpz, &config_mpz_ret) != XIP_STATUS_OK) {
    cerr << "ERROR: Could not retrieve C model configuration" << endl;
  }

  //reuse int number_of_samples = DATA_SIZE; from earlier
  // Declare any arrays in the request structure and write pointers to them into the request structure

  // Create request and response structures
  // Create input data packet for operand A
  xip_array_mpz_complex* reqa_mpz = xip_array_mpz_complex_create();
  xip_array_mpz_complex_reserve_dim(reqa_mpz,1); //dimensions are (Number of samples)
  reqa_mpz->dim_size = 1;
  reqa_mpz->dim[0] = number_of_samples;
  reqa_mpz->data_size = reqa_mpz->dim[0];
  if (xip_array_mpz_complex_reserve_data(reqa_mpz,reqa_mpz->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for A request as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for input data packet!" << endl;
    exit(2);
  }


  // Create input data packet for operand B
  xip_array_mpz_complex* reqb_mpz = xip_array_mpz_complex_create();
  xip_array_mpz_complex_reserve_dim(reqb_mpz,1); //dimensions are (Number of samples)
  reqb_mpz->dim_size = 1;
  reqb_mpz->dim[0] = number_of_samples;
  reqb_mpz->data_size = reqb_mpz->dim[0];
  if (xip_array_mpz_complex_reserve_data(reqb_mpz,reqb_mpz->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for B request as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for input data packet!" << endl;
    exit(2);
  }

  //create new rounding bit array
  xip_array_uint* reqctrl2 = xip_array_uint_create();
  xip_array_uint_reserve_dim(reqctrl2,1); //dimensions are (Number of samples)
  reqctrl2->dim_size = 1;
  reqctrl2->dim[0] = number_of_samples;
  reqctrl2->data_size = reqctrl2->dim[0];
  if (xip_array_uint_reserve_data(reqctrl2,reqctrl2->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for request as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for input data packet!" << endl;
    exit(2);
  }

  //create input data
  xip_mpz_complex c,d;
  xip_mpz_complex value_mpz;
  mpz_init(c.re);
  mpz_init(c.im);
  mpz_init(d.re);
  mpz_init(d.im);
  mpz_init(value_mpz.re);
  mpz_init(value_mpz.im);

  unsigned long int hh = 0;
  for (size_t h = 0; h < DATA_SIZE; h++)
  {
    hh++;
    roundbit = (xip_uint)(1 - (hh % 2));
    //insert any old example data based on the loop index
    mpz_set_ui(c.re, 2*hh+6);
    mpz_set_ui(c.im, 5*hh);
    mpz_set_ui(d.re, 5);
    mpz_set_ui(d.im, (16-hh));
    if (xip_cmpy_v6_0_xip_array_mpz_complex_set_data(reqa_mpz, c, h) != XIP_STATUS_OK)
      cerr << "Error in mpz_complex_set_data" << endl;

    if (xip_cmpy_v6_0_xip_array_mpz_complex_set_data(reqb_mpz, d, h) != XIP_STATUS_OK)
      cerr << "Error in mpz_complex_set_data" << endl;

    if (xip_cmpy_v6_0_xip_array_uint_set_data(reqctrl2, roundbit, h) != XIP_STATUS_OK)
      cerr << "Error in uint_set_data" << endl;

    printf("C (%d) ",(int)h);
    print_mpz_complex(c);
    printf("D (%d) ", (int)h);
    print_mpz_complex(d);
    printf("Round bit for sample %d is %d\n", (int)h, roundbit);

#if(DEBUG)
    if (xip_cmpy_v6_0_xip_array_mpz_complex_get_data(reqb_mpz, &value_mpz, h) != XIP_STATUS_OK)
      cerr << "Error in complex_get_data" << endl;
#endif
  }
  mpz_clear(c.re);
  mpz_clear(c.im);
  mpz_clear(d.re);
  mpz_clear(d.im);
  mpz_clear(value_mpz.re);
  mpz_clear(value_mpz.im);

  // Request memory for output data
  xip_array_mpz_complex* response_mpz = xip_array_mpz_complex_create();
  xip_array_mpz_complex_reserve_dim(response_mpz,1); //dimensions are (Number of samples)
  response_mpz->dim_size = 1;
  response_mpz->dim[0] = number_of_samples;
  response_mpz->data_size = response_mpz->dim[0];
  if (xip_array_mpz_complex_reserve_data(response_mpz,response_mpz->data_size) == XIP_STATUS_OK) {
    cout << "INFO: Reserved memory for response as [" << number_of_samples << "] array " << endl;
  } else {
    cout << "ERROR: Unable to reserve memory for output data packet!" << endl;
    exit(3);
  }

  // Run the model
  cout << "Running the C model..." << endl;

  if (xip_cmpy_v6_0_mpz_data_do(cmpy_mpz, reqa_mpz, reqb_mpz, reqctrl2, response_mpz) != XIP_STATUS_OK)  {
    cerr << "ERROR: C model did not complete successfully" << endl;
    xip_array_mpz_complex_destroy(reqa_mpz);
    xip_array_mpz_complex_destroy(reqb_mpz);
    xip_array_uint_destroy(reqctrl2);
    xip_array_mpz_complex_destroy(response_mpz);
    xip_cmpy_v6_0_destroy(cmpy_mpz);
    return XIP_STATUS_ERROR;
  } else {
    cout << "C model completed successfully" << endl;
  }

#if(DEBUG)
  // When enabled, this will print the result data to stdout
  xip_mpz_complex readout_val;
  mpz_init(readout_val.re);
  mpz_init(readout_val.im);
  for(size_t sample = 0; sample < number_of_samples; sample++) {
    xip_cmpy_v6_0_xip_array_mpz_complex_get_data(response_mpz, &readout_val, sample);
    printf("result (%d) ",(int)sample);
    print_mpz_complex(readout_val);
  }
  mpz_clear(readout_val.re);
  mpz_clear(readout_val.im);
#endif

  // Check response is correct
  xip_mpz_complex expected_mpz, got_mpz, x_mpz, y_mpz;
  mpz_t dummy;
  mpz_init(expected_mpz.re);
  mpz_init(expected_mpz.im);
  mpz_init(got_mpz.re);
  mpz_init(got_mpz.im);
  mpz_init(x_mpz.re);
  mpz_init(x_mpz.im);
  mpz_init(y_mpz.re);
  mpz_init(y_mpz.im);
  mpz_init(dummy);
  for (int k = 0; k < DATA_SIZE; k++) {
    xip_uint round_bit;
    xip_cmpy_v6_0_xip_array_mpz_complex_get_data(reqa_mpz, &x_mpz, k);
    xip_cmpy_v6_0_xip_array_mpz_complex_get_data(reqb_mpz, &y_mpz, k);
    xip_cmpy_v6_0_xip_array_uint_get_data(reqctrl2, &round_bit, k);
    xip_cmpy_v6_0_xip_array_mpz_complex_get_data(response_mpz, &got_mpz, k);

    //Calculate raw real part
    mpz_mul(expected_mpz.re, x_mpz.re, y_mpz.re);
    mpz_mul(dummy, x_mpz.im, y_mpz.im);
    mpz_sub(expected_mpz.re, expected_mpz.re, dummy);

    //Calculate raw imaginary part
    mpz_mul(expected_mpz.im, x_mpz.re, y_mpz.im);
    mpz_mul(dummy, x_mpz.im, y_mpz.re);
    mpz_add(expected_mpz.im, expected_mpz.im, dummy);

    //Apply rounding constant (+0.5 or +0.49999)
    if (config_mpz.RoundMode == XIP_CMPY_V6_0_ROUND){
      mpz_set_ui(dummy, 1UL);
      mpz_mul_2exp(dummy, dummy, (NaturalWidth-config_mpz.OutputWidth-1));
      if (round_bit == 0) {
        mpz_sub_ui(dummy, dummy, 1);
      }
      mpz_add(expected_mpz.re, expected_mpz.re, dummy);
      mpz_add(expected_mpz.im, expected_mpz.im, dummy);
    }

    //Truncate raw result to get desired (expected) result.
    mpz_fdiv_q_2exp(expected_mpz.re, expected_mpz.re, (NaturalWidth-config_mpz.OutputWidth));
    mpz_fdiv_q_2exp(expected_mpz.im, expected_mpz.im, (NaturalWidth-config_mpz.OutputWidth));

    //Compare expected result to that from the model
    if (mpz_cmp(expected_mpz.re, got_mpz.re) == 0 && mpz_cmp(expected_mpz.im, got_mpz.im) == 0) {
      cout << "Sample " << k << " was as expected." << endl;
    } else {
      cerr << "ERROR: C model data output is incorrect" << endl;
      printf("Sample (%d)\n     got ",k);
      print_mpz_complex(got_mpz);
      printf("expected ");
      print_mpz_complex(expected_mpz);
      printf("\n");
      xip_array_mpz_complex_destroy(reqa_mpz);
      xip_array_mpz_complex_destroy(reqb_mpz);
      xip_array_uint_destroy(reqctrl2);
      xip_array_mpz_complex_destroy(response_mpz);
      xip_cmpy_v6_0_destroy(cmpy_mpz);
      return XIP_STATUS_ERROR;
    }
  }
  cout << "C model data output is correct" << endl;

  // Clean up
  mpz_clear(expected_mpz.re);
  mpz_clear(expected_mpz.im);
  mpz_clear(got_mpz.re);
  mpz_clear(got_mpz.im);
  mpz_clear(x_mpz.re);
  mpz_clear(x_mpz.im);
  mpz_clear(y_mpz.re);
  mpz_clear(y_mpz.im);
  mpz_clear(dummy);

  xip_array_mpz_complex_destroy(reqa_mpz);
  xip_array_mpz_complex_destroy(reqb_mpz);
  xip_array_uint_destroy(reqctrl2);
  xip_array_mpz_complex_destroy(response_mpz);
  cout << "C model input and output data freed" << endl;

  xip_cmpy_v6_0_destroy(cmpy_mpz);
  cout << "C model destroyed" << endl;

  // We will already have returned if there was an error
  return XIP_STATUS_OK;
}
